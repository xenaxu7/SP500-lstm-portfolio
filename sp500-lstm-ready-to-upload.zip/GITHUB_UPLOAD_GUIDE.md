# 📝 GitHub上传详细教程

## 方法1：通过GitHub网页直接上传（最简单！）

### Step 1: 创建新仓库
1. 打开 https://github.com/xenaxu7
2. 点击右上角的 **"+"** → **"New repository"**
3. 填写信息：
   - **Repository name**: `sp500-lstm-portfolio`
   - **Description**: `LSTM neural network for S&P 500 stock selection and portfolio optimization`
   - **Public/Private**: 选 **Public**（找工作需要展示）
   - ❌ **不要**勾选 "Add a README file"（我们已经有了）
   - ❌ **不要**勾选 "Add .gitignore"
   - ❌ **不要**选择 license
4. 点击 **"Create repository"**

### Step 2: 上传文件
1. 创建后会看到一个空仓库页面
2. 找到 **"uploading an existing file"** 链接，点击它
3. 或者直接点击 **"Upload files"** 按钮
4. **解压我给你的ZIP文件到本地文件夹**
5. 把解压后的**所有文件和文件夹**拖拽到GitHub页面的上传区域
   - 注意：要上传整个文件夹结构，包括 src/, data/, models/, results/ 等文件夹
6. 在下方 **"Commit changes"** 区域：
   - 输入 commit message: `Initial commit: LSTM portfolio selection system`
7. 点击 **"Commit changes"** 按钮

## 方法2：使用Git命令行（更专业）

### 前置准备
```bash
# 1. 安装Git（如果还没装）
# Windows: 下载 https://git-scm.com/download/win
# Mac: brew install git
# Linux: sudo apt-get install git

# 2. 配置Git（第一次使用需要）
git config --global user.name "Xena Xu"
git config --global user.email "xenaxu7@gmail.com"
```

### 上传步骤
```bash
# 1. 解压下载的ZIP文件
# 假设解压到了 ~/Downloads/sp500-lstm-portfolio 文件夹

# 2. 进入项目文件夹
cd ~/Downloads/sp500-lstm-portfolio

# 3. 初始化Git仓库
git init

# 4. 添加所有文件
git add .

# 5. 创建第一次提交
git commit -m "Initial commit: LSTM portfolio selection system"

# 6. 添加远程仓库（替换成你创建的仓库地址）
git remote add origin https://github.com/xenaxu7/sp500-lstm-portfolio.git

# 7. 推送到GitHub
git branch -M main
git push -u origin main

# 如果要求输入用户名密码：
# Username: xenaxu7
# Password: 你的GitHub密码或Personal Access Token
```

## 方法3：使用GitHub Desktop（图形界面）

1. 下载 GitHub Desktop: https://desktop.github.com/
2. 登录你的GitHub账号
3. 点击 **"File"** → **"Add Local Repository"**
4. 选择解压后的项目文件夹
5. 如果提示不是Git仓库，选择 **"Create a Repository"**
6. 点击 **"Publish repository"** 按钮
7. 确保仓库名是 `sp500-lstm-portfolio`
8. 取消勾选 **"Keep this code private"**
9. 点击 **"Publish Repository"**

## ⚠️ 常见问题

### Q: 上传时显示文件太大？
某些文件可能超过GitHub的100MB限制。解决方案：
- 不要上传大的数据文件（.csv超过100MB的）
- 使用.gitignore忽略大文件

### Q: 文件夹没有上传？
- GitHub不会上传空文件夹
- 我已经在每个文件夹放了.gitkeep文件，应该没问题

### Q: 需要Personal Access Token？
GitHub现在不允许直接用密码push，需要创建token：
1. GitHub → Settings → Developer settings
2. Personal access tokens → Tokens (classic)
3. Generate new token
4. 勾选 `repo` 权限
5. 复制token，当密码使用

## 🎯 上传后的检查清单

✅ 确认以下文件/文件夹都在：
- [ ] README.md（显示在主页）
- [ ] requirements.txt
- [ ] main.py
- [ ] lstm_stock_selection_standalone.py
- [ ] src/ 文件夹（包含所有.py文件）
- [ ] data/, models/, results/ 文件夹（可能为空但有.gitkeep）

✅ README.md是否正确显示（带格式和emoji）

✅ 项目结构清晰，文件组织合理

## 💡 上传成功后

1. **分享链接**: `https://github.com/xenaxu7/sp500-lstm-portfolio`
2. **添加到简历**: "GitHub: github.com/xenaxu7"
3. **LinkedIn更新**: 在项目经历里添加GitHub链接
4. **Pin仓库**: 在你的GitHub主页，点击 "Customize your pins"，选择这个项目

---

有问题随时问我！加油 Xena! 🚀
