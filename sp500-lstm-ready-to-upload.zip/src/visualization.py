"""
Visualization utilities for portfolio performance
"""

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from typing import Dict, Any
import os
import seaborn as sns

class Visualizer:
    """Handle all visualization tasks"""
    
    def __init__(self, config):
        self.config = config
        # Set style
        plt.style.use('seaborn-v0_8-darkgrid')
        sns.set_palette("husl")
        
    def plot_performance_comparison(self, results: Dict[str, Any]):
        """Plot cumulative returns comparison"""
        
        # Create output directories
        os.makedirs(self.config.FIGURES_DIR, exist_ok=True)
        
        # Create main performance plot
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # Plot 1: Cumulative Returns
        ax1 = axes[0, 0]
        self._plot_cumulative_returns(ax1, results)
        
        # Plot 2: Drawdown
        ax2 = axes[0, 1]
        self._plot_drawdown(ax2, results)
        
        # Plot 3: Risk-Return Scatter
        ax3 = axes[1, 0]
        self._plot_risk_return(ax3, results)
        
        # Plot 4: Monthly Returns Heatmap
        ax4 = axes[1, 1]
        self._plot_returns_distribution(ax4, results)
        
        plt.suptitle('Portfolio Performance Analysis', fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        # Save figure
        filepath = os.path.join(self.config.FIGURES_DIR, 'performance_analysis.png')
        plt.savefig(filepath, dpi=self.config.DPI, bbox_inches='tight')
        print(f"\n📊 Performance chart saved to: {filepath}")
        
        plt.show()
        
    def _plot_cumulative_returns(self, ax, results: Dict[str, Any]):
        """Plot cumulative returns comparison"""
        
        colors = {'lstm': 'blue', 'thematic': 'green', 'spy': 'red'}
        styles = {'lstm': '-', 'thematic': '-', 'spy': '--'}
        
        for portfolio_name in ['lstm', 'thematic', 'spy']:
            if portfolio_name in results:
                cumulative_returns = results[portfolio_name]['cumulative_returns']
                if not cumulative_returns.empty:
                    ax.plot(cumulative_returns.index,
                           cumulative_returns.values,
                           label=results[portfolio_name]['portfolio_name'],
                           linewidth=2,
                           color=colors[portfolio_name],
                           linestyle=styles[portfolio_name])
        
        ax.set_title('Cumulative Returns Comparison', fontweight='bold')
        ax.set_xlabel('Date')
        ax.set_ylabel('Cumulative Return')
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3)
        
    def _plot_drawdown(self, ax, results: Dict[str, Any]):
        """Plot drawdown comparison"""
        
        colors = {'lstm': 'blue', 'thematic': 'green', 'spy': 'red'}
        
        for portfolio_name in ['lstm', 'thematic', 'spy']:
            if portfolio_name in results:
                cumulative_returns = results[portfolio_name]['cumulative_returns']
                if not cumulative_returns.empty:
                    # Calculate drawdown
                    running_max = cumulative_returns.expanding().max()
                    drawdown = (cumulative_returns - running_max) / running_max
                    
                    ax.fill_between(drawdown.index,
                                   drawdown.values,
                                   0,
                                   label=results[portfolio_name]['portfolio_name'],
                                   alpha=0.3,
                                   color=colors[portfolio_name])
        
        ax.set_title('Portfolio Drawdown', fontweight='bold')
        ax.set_xlabel('Date')
        ax.set_ylabel('Drawdown (%)')
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3)
        
    def _plot_risk_return(self, ax, results: Dict[str, Any]):
        """Plot risk-return scatter"""
        
        colors = {'lstm': 'blue', 'thematic': 'green', 'spy': 'red'}
        sizes = {'lstm': 200, 'thematic': 200, 'spy': 150}
        
        for portfolio_name in ['lstm', 'thematic', 'spy']:
            if portfolio_name in results:
                metrics = results[portfolio_name]
                ax.scatter(metrics['annual_volatility'],
                          metrics['annual_return'],
                          s=sizes[portfolio_name],
                          color=colors[portfolio_name],
                          alpha=0.7,
                          label=metrics['portfolio_name'],
                          edgecolors='black',
                          linewidth=1)
        
        # Add Sharpe ratio lines
        volatilities = np.linspace(0, 0.4, 100)
        for sharpe in [0.5, 1.0, 1.5]:
            returns = sharpe * volatilities + self.config.RISK_FREE_RATE
            ax.plot(volatilities, returns, 'k--', alpha=0.3, linewidth=0.5)
            ax.text(volatilities[-1], returns[-1], f'SR={sharpe}', 
                   fontsize=8, alpha=0.5)
        
        ax.set_title('Risk-Return Profile', fontweight='bold')
        ax.set_xlabel('Annual Volatility')
        ax.set_ylabel('Annual Return')
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3)
        
    def _plot_returns_distribution(self, ax, results: Dict[str, Any]):
        """Plot returns distribution"""
        
        # This would need the actual returns data
        # For now, show metrics comparison as bar chart
        
        metrics_to_plot = ['total_return', 'sharpe_ratio', 'max_drawdown']
        portfolio_names = []
        metric_values = {m: [] for m in metrics_to_plot}
        
        for portfolio_name in ['lstm', 'thematic', 'spy']:
            if portfolio_name in results:
                portfolio_names.append(results[portfolio_name]['portfolio_name'])
                for metric in metrics_to_plot:
                    metric_values[metric].append(results[portfolio_name][metric])
        
        x = np.arange(len(portfolio_names))
        width = 0.25
        
        for i, metric in enumerate(metrics_to_plot):
            offset = (i - 1) * width
            bars = ax.bar(x + offset, metric_values[metric], width, 
                         label=metric.replace('_', ' ').title())
            
            # Add value labels on bars
            for bar in bars:
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{height:.2f}' if abs(height) < 10 else f'{height:.1%}',
                       ha='center', va='bottom' if height >= 0 else 'top',
                       fontsize=8)
        
        ax.set_title('Key Metrics Comparison', fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(portfolio_names, rotation=45, ha='right')
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3, axis='y')
        
    def save_results_to_csv(self, results: Dict[str, Any]):
        """Save results to CSV files"""
        
        os.makedirs(self.config.METRICS_DIR, exist_ok=True)
        
        # Create summary dataframe
        summary_data = []
        
        for portfolio_name in ['lstm', 'thematic', 'spy']:
            if portfolio_name in results:
                metrics = results[portfolio_name]
                summary_data.append({
                    'Portfolio': metrics['portfolio_name'],
                    'Total Return': metrics['total_return'],
                    'Annual Return': metrics['annual_return'],
                    'Volatility': metrics['annual_volatility'],
                    'Sharpe Ratio': metrics['sharpe_ratio'],
                    'Sortino Ratio': metrics.get('sortino_ratio', 0),
                    'Calmar Ratio': metrics.get('calmar_ratio', 0),
                    'Max Drawdown': metrics['max_drawdown'],
                    'Win Rate': metrics.get('win_rate', 0)
                })
        
        summary_df = pd.DataFrame(summary_data)
        
        # Save to CSV
        filepath = os.path.join(self.config.METRICS_DIR, 'performance_summary.csv')
        summary_df.to_csv(filepath, index=False)
        print(f"📊 Results saved to: {filepath}")
        
        # Save cumulative returns
        returns_data = {}
        for portfolio_name in ['lstm', 'thematic', 'spy']:
            if portfolio_name in results:
                cumulative_returns = results[portfolio_name]['cumulative_returns']
                if not cumulative_returns.empty:
                    returns_data[results[portfolio_name]['portfolio_name']] = cumulative_returns
        
        if returns_data:
            returns_df = pd.DataFrame(returns_data)
            filepath = os.path.join(self.config.METRICS_DIR, 'cumulative_returns.csv')
            returns_df.to_csv(filepath)
            print(f"📊 Cumulative returns saved to: {filepath}")
    
    def create_tearsheet(self, results: Dict[str, Any]):
        """Create a comprehensive tearsheet (future enhancement)"""
        # To be implemented - would create a PDF report
        pass
