"""
Data loading utilities for S&P 500 stock data
"""

import pandas as pd
import yfinance as yf
import numpy as np
from typing import Tuple, List, Optional

class SP500DataLoader:
    """Handles all data loading operations for S&P 500 stocks"""
    
    def __init__(self, config):
        self.config = config
        self.sp500_tickers = self._get_sp500_tickers()
        
    def _get_sp500_tickers(self) -> List[str]:
        """Fetch S&P 500 tickers from Wikipedia or use fallback list"""
        try:
            # Try to fetch from Wikipedia
            sp500_table = pd.read_html('https://en.wikipedia.org/wiki/List_of_S%26P_500_companies')
            tickers = sp500_table[0]['Symbol'].tolist()
            # Clean tickers (remove dots for special classes)
            tickers = [ticker.replace('.', '-') for ticker in tickers]
            print(f"✓ Successfully fetched {len(tickers)} S&P 500 tickers from Wikipedia")
            return tickers
        except:
            print("⚠ Using fallback S&P 500 ticker list...")
            # Fallback to hardcoded list (abbreviated for space)
            return self._get_fallback_tickers()
    
    def _get_fallback_tickers(self) -> List[str]:
        """Return hardcoded S&P 500 tickers as fallback"""
        # Top S&P 500 companies (abbreviated list for demonstration)
        return [
            'AAPL', 'MSFT', 'AMZN', 'NVDA', 'GOOGL', 'META', 'TSLA', 'BRK-B', 
            'GOOG', 'UNH', 'XOM', 'JPM', 'JNJ', 'V', 'PG', 'MA', 'AVGO', 'HD', 
            'CVX', 'MRK', 'LLY', 'PEP', 'ABBV', 'KO', 'COST', 'WMT', 'BAC', 
            'MCD', 'CRM', 'ACN', 'ADBE', 'TMO', 'CSCO', 'ABT', 'NFLX', 'PFE',
            'TMUS', 'ORCL', 'CMCSA', 'VZ', 'DHR', 'DIS', 'INTC', 'NKE', 'INTU',
            'WFC', 'TXN', 'PM', 'COP', 'UNP', 'RTX', 'AMGN', 'HON', 'BA', 'BMY',
            'QCOM', 'NEE', 'IBM', 'UPS', 'LOW', 'SPGI', 'LMT', 'DE', 'CAT', 'SBUX',
            'GE', 'AMD', 'MDT', 'PLD', 'AMAT', 'GS', 'SYK', 'BLK', 'ISRG', 'GILD',
            # Add more tickers as needed...
        ]
    
    def download_stock_data(self, tickers: List[str], start_date, end_date) -> pd.DataFrame:
        """Download historical stock data for given tickers"""
        print(f"Downloading {len(tickers)} stocks from {start_date.date()} to {end_date.date()}...")
        
        try:
            # Download all at once with progress bar
            data = yf.download(
                tickers, 
                start=start_date, 
                end=end_date, 
                progress=True, 
                threads=True, 
                group_by='ticker'
            )
            
            # Extract Adjusted Close prices
            close_data = self._extract_close_prices(data, tickers)
            
            # Remove stocks with too many missing values
            threshold = len(close_data) * self.config.MIN_DATA_THRESHOLD
            close_data = close_data.dropna(axis=1, thresh=threshold)
            
            print(f"✓ Successfully downloaded {len(close_data.columns)} out of {len(tickers)} stocks")
            return close_data
            
        except Exception as e:
            print(f"⚠ Error downloading data: {e}")
            return pd.DataFrame()
    
    def _extract_close_prices(self, data: pd.DataFrame, tickers: List[str]) -> pd.DataFrame:
        """Extract adjusted close prices from downloaded data"""
        close_data = pd.DataFrame()
        
        if isinstance(data.columns, pd.MultiIndex):
            # Multi-ticker download returns MultiIndex columns
            for ticker in tickers:
                try:
                    if ticker in data.columns.levels[0]:
                        close_data[ticker] = data[ticker]['Adj Close']
                except:
                    try:
                        close_data[ticker] = data[ticker]['Close']
                    except:
                        continue
        else:
            close_data = data
            
        return close_data
    
    def load_all_data(self) -> Tuple[pd.DataFrame, pd.DataFrame, List[str]]:
        """Load training and testing data for all S&P 500 stocks"""
        print("\n" + "="*60)
        print("DATA LOADING PHASE")
        print("="*60)
        
        # Download training data
        print("\nDownloading training data...")
        train_data = self.download_stock_data(
            self.sp500_tickers,
            self.config.TRAINING_START,
            self.config.TRAINING_END
        )
        
        # Download testing data for the same stocks
        print("\nDownloading testing data...")
        available_tickers = train_data.columns.tolist()
        test_data = self.download_stock_data(
            available_tickers,
            self.config.TESTING_START,
            self.config.TESTING_END
        )
        
        print(f"\nData shapes:")
        print(f"Training data: {train_data.shape} (days x stocks)")
        print(f"Testing data: {test_data.shape} (days x stocks)")
        
        return train_data, test_data, available_tickers
    
    def get_benchmark_data(self, symbol: str = 'SPY') -> pd.DataFrame:
        """Download benchmark index data"""
        print(f"\nDownloading {symbol} benchmark data...")
        
        spy_data = yf.download(
            symbol, 
            start=self.config.TESTING_START, 
            end=self.config.TESTING_END, 
            progress=False
        )
        
        if isinstance(spy_data.columns, pd.MultiIndex):
            spy_prices = spy_data['Adj Close'].squeeze()
        else:
            spy_prices = spy_data['Adj Close'] if 'Adj Close' in spy_data.columns else spy_data['Close']
            
        return spy_prices
