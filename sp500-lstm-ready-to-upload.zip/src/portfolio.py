"""
Portfolio construction and management utilities
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple

class PortfolioConstructor:
    """Handles portfolio construction and management"""
    
    def __init__(self, config):
        self.config = config
        
    def create_lstm_portfolio(self, predictions: Dict[str, float], 
                             n_stocks: int) -> Dict:
        """Create portfolio based on LSTM predictions"""
        
        # Sort stocks by predicted return
        sorted_stocks = sorted(predictions.items(), 
                             key=lambda x: x[1], 
                             reverse=True)
        
        # Select top n stocks
        selected_stocks = [stock[0] for stock in sorted_stocks[:n_stocks]]
        
        # Equal weighting
        weights = {stock: 1.0/n_stocks for stock in selected_stocks}
        
        portfolio = {
            'stocks': selected_stocks,
            'weights': weights,
            'predictions': {s: predictions[s] for s in selected_stocks},
            'strategy': 'LSTM_Equal_Weight'
        }
        
        print(f"\n📊 LSTM Portfolio Created:")
        print(f"   • Number of stocks: {len(selected_stocks)}")
        print(f"   • Average predicted return: {np.mean(list(portfolio['predictions'].values())):.2%}")
        
        return portfolio
    
    def create_thematic_portfolio(self) -> Dict:
        """Create thematic portfolio based on predefined selection"""
        
        # Use stocks from config
        thematic_stocks = self.config.THEMATIC_STOCKS[:self.config.NUM_STOCKS_TO_SELECT]
        
        # Equal weighting
        weights = {stock: 1.0/len(thematic_stocks) for stock in thematic_stocks}
        
        portfolio = {
            'stocks': thematic_stocks,
            'weights': weights,
            'predictions': None,
            'strategy': 'Thematic_Equal_Weight'
        }
        
        print(f"\n📊 Thematic Portfolio Created:")
        print(f"   • Number of stocks: {len(thematic_stocks)}")
        print(f"   • Sectors: Technology, Healthcare, Finance, Consumer")
        
        return portfolio
    
    def create_market_cap_weighted_portfolio(self, stocks: List[str]) -> Dict:
        """Create market-cap weighted portfolio (future enhancement)"""
        # To be implemented
        pass
    
    def create_optimized_portfolio(self, stocks: List[str], 
                                  returns: pd.DataFrame) -> Dict:
        """Create mean-variance optimized portfolio (future enhancement)"""
        # To be implemented using PyPortfolioOpt
        pass
    
    def rebalance_portfolio(self, portfolio: Dict, 
                           new_data: pd.DataFrame) -> Dict:
        """Rebalance existing portfolio (future enhancement)"""
        # To be implemented
        pass
    
    def get_portfolio_summary(self, portfolio: Dict) -> pd.DataFrame:
        """Get summary statistics for portfolio"""
        
        summary_data = []
        
        for stock, weight in portfolio['weights'].items():
            row = {
                'Stock': stock,
                'Weight': weight,
                'Predicted Return': portfolio['predictions'].get(stock, np.nan) 
                                   if portfolio['predictions'] else np.nan
            }
            summary_data.append(row)
        
        summary_df = pd.DataFrame(summary_data)
        summary_df = summary_df.sort_values('Weight', ascending=False)
        
        return summary_df
    
    def calculate_portfolio_returns(self, portfolio: Dict, 
                                   returns_data: pd.DataFrame) -> pd.Series:
        """Calculate portfolio returns based on weights"""
        
        # Get available stocks
        available_stocks = [s for s in portfolio['stocks'] 
                          if s in returns_data.columns]
        
        if not available_stocks:
            return pd.Series()
        
        # Recalculate weights if some stocks are missing
        if len(available_stocks) < len(portfolio['stocks']):
            print(f"⚠ {len(portfolio['stocks']) - len(available_stocks)} stocks not available in returns data")
            weights = {s: 1.0/len(available_stocks) for s in available_stocks}
        else:
            weights = portfolio['weights']
        
        # Calculate weighted returns
        portfolio_returns = pd.Series(0, index=returns_data.index)
        
        for stock in available_stocks:
            portfolio_returns += returns_data[stock] * weights[stock]
        
        return portfolio_returns
