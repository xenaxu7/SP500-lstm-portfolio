"""
S&P 500 LSTM Portfolio Selection System
A quantitative trading strategy using deep learning
"""

from .config import Config
from .data_loader import SP500DataLoader
from .lstm_model import LSTMPredictor
from .portfolio import PortfolioConstructor
from .evaluation import PerformanceEvaluator
from .visualization import Visualizer

__version__ = "1.0.0"
__author__ = "Xena Xu"

__all__ = [
    'Config',
    'SP500DataLoader',
    'LSTMPredictor',
    'PortfolioConstructor',
    'PerformanceEvaluator',
    'Visualizer'
]
