"""
Performance evaluation and metrics calculation
"""

import pandas as pd
import numpy as np
from typing import Dict, Any
import yfinance as yf

class PerformanceEvaluator:
    """Evaluate portfolio performance and calculate metrics"""
    
    def __init__(self, config):
        self.config = config
        
    def calculate_metrics(self, returns: pd.Series) -> Dict[str, float]:
        """Calculate comprehensive performance metrics"""
        
        if returns.empty:
            return self._empty_metrics()
        
        # Calculate cumulative returns
        cumulative_returns = (1 + returns).cumprod()
        
        # Total return
        total_return = cumulative_returns.iloc[-1] - 1
        
        # Annualized return
        n_days = len(returns)
        annual_return = (1 + total_return) ** (252 / n_days) - 1
        
        # Volatility
        annual_volatility = returns.std() * np.sqrt(252)
        
        # Sharpe ratio
        sharpe_ratio = (annual_return - self.config.RISK_FREE_RATE) / annual_volatility \
                      if annual_volatility > 0 else 0
        
        # Maximum drawdown
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        max_drawdown = drawdown.min()
        
        # Calmar ratio
        calmar_ratio = annual_return / abs(max_drawdown) if max_drawdown != 0 else 0
        
        # Sortino ratio (using downside deviation)
        downside_returns = returns[returns < 0]
        downside_std = downside_returns.std() * np.sqrt(252)
        sortino_ratio = (annual_return - self.config.RISK_FREE_RATE) / downside_std \
                       if downside_std > 0 else 0
        
        # Win rate
        win_rate = (returns > 0).sum() / len(returns) if len(returns) > 0 else 0
        
        return {
            'total_return': total_return,
            'annual_return': annual_return,
            'annual_volatility': annual_volatility,
            'sharpe_ratio': sharpe_ratio,
            'sortino_ratio': sortino_ratio,
            'calmar_ratio': calmar_ratio,
            'max_drawdown': max_drawdown,
            'win_rate': win_rate,
            'cumulative_returns': cumulative_returns
        }
    
    def _empty_metrics(self) -> Dict[str, float]:
        """Return empty metrics dictionary"""
        return {
            'total_return': 0,
            'annual_return': 0,
            'annual_volatility': 0,
            'sharpe_ratio': 0,
            'sortino_ratio': 0,
            'calmar_ratio': 0,
            'max_drawdown': 0,
            'win_rate': 0,
            'cumulative_returns': pd.Series()
        }
    
    def evaluate_portfolio(self, portfolio: Dict, 
                          test_data: pd.DataFrame) -> Dict[str, Any]:
        """Evaluate a single portfolio"""
        
        # Calculate daily returns
        daily_returns = test_data.pct_change().dropna()
        
        # Calculate portfolio returns
        from src.portfolio import PortfolioConstructor
        constructor = PortfolioConstructor(self.config)
        portfolio_returns = constructor.calculate_portfolio_returns(portfolio, daily_returns)
        
        # Calculate metrics
        metrics = self.calculate_metrics(portfolio_returns)
        
        # Add portfolio info
        metrics['portfolio_name'] = portfolio['strategy']
        metrics['n_stocks'] = len(portfolio['stocks'])
        
        return metrics
    
    def evaluate_benchmark(self, symbol: str = 'SPY') -> Dict[str, Any]:
        """Evaluate benchmark performance"""
        
        # Download benchmark data
        from src.data_loader import SP500DataLoader
        loader = SP500DataLoader(self.config)
        spy_prices = loader.get_benchmark_data(symbol)
        
        # Calculate returns
        spy_returns = spy_prices.pct_change().dropna()
        
        # Calculate metrics
        metrics = self.calculate_metrics(spy_returns)
        metrics['portfolio_name'] = f'{symbol} Benchmark'
        
        return metrics
    
    def evaluate_all_portfolios(self, lstm_portfolio: Dict, 
                               thematic_portfolio: Dict,
                               test_data: pd.DataFrame) -> Dict[str, Any]:
        """Evaluate all portfolios and benchmark"""
        
        print("\n" + "="*60)
        print("PERFORMANCE EVALUATION")
        print("="*60)
        
        results = {}
        
        # Evaluate LSTM portfolio
        print("\n📈 Evaluating LSTM Portfolio...")
        results['lstm'] = self.evaluate_portfolio(lstm_portfolio, test_data)
        
        # Evaluate thematic portfolio
        print("📈 Evaluating Thematic Portfolio...")
        results['thematic'] = self.evaluate_portfolio(thematic_portfolio, test_data)
        
        # Evaluate benchmark
        print("📈 Evaluating S&P 500 Benchmark...")
        results['spy'] = self.evaluate_benchmark('SPY')
        
        # Determine best performer
        best_return = -float('inf')
        best_performer = None
        
        for name, metrics in results.items():
            if metrics['total_return'] > best_return:
                best_return = metrics['total_return']
                best_performer = name
                
        results['best_performer'] = best_performer
        
        # Print comparison table
        self._print_comparison_table(results)
        
        return results
    
    def _print_comparison_table(self, results: Dict[str, Any]):
        """Print formatted comparison table"""
        
        print("\n" + "="*60)
        print("PERFORMANCE COMPARISON")
        print("="*60)
        
        # Create comparison dataframe
        comparison_data = []
        
        for portfolio_name in ['lstm', 'thematic', 'spy']:
            if portfolio_name in results:
                metrics = results[portfolio_name]
                comparison_data.append({
                    'Portfolio': metrics['portfolio_name'],
                    'Total Return': f"{metrics['total_return']:.2%}",
                    'Annual Return': f"{metrics['annual_return']:.2%}",
                    'Volatility': f"{metrics['annual_volatility']:.2%}",
                    'Sharpe Ratio': f"{metrics['sharpe_ratio']:.2f}",
                    'Max Drawdown': f"{metrics['max_drawdown']:.2%}",
                    'Win Rate': f"{metrics['win_rate']:.1%}"
                })
        
        comparison_df = pd.DataFrame(comparison_data)
        print("\n" + comparison_df.to_string(index=False))
        
    def calculate_rolling_metrics(self, returns: pd.Series, 
                                 window: int = 252) -> pd.DataFrame:
        """Calculate rolling performance metrics"""
        
        rolling_returns = returns.rolling(window=window).apply(
            lambda x: (1 + x).prod() - 1
        )
        
        rolling_volatility = returns.rolling(window=window).std() * np.sqrt(252)
        
        rolling_sharpe = (rolling_returns * (252/window) - self.config.RISK_FREE_RATE) / rolling_volatility
        
        rolling_metrics = pd.DataFrame({
            'Rolling_Return': rolling_returns,
            'Rolling_Volatility': rolling_volatility,
            'Rolling_Sharpe': rolling_sharpe
        })
        
        return rolling_metrics
