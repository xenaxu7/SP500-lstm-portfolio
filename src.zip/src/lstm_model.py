"""
LSTM model implementation for stock price prediction
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM
from typing import Dict, Optional, Tuple
import pickle
import os

class LSTMPredictor:
    """LSTM model for stock return prediction"""
    
    def __init__(self, config):
        self.config = config
        self.models = {}
        self.scalers = {}
        
    def create_model(self, input_shape: Tuple) -> Sequential:
        """Create LSTM model architecture"""
        model = Sequential([
            LSTM(
                self.config.LSTM_UNITS_1, 
                return_sequences=True, 
                input_shape=input_shape
            ),
            LSTM(
                self.config.LSTM_UNITS_2, 
                return_sequences=False
            ),
            Dense(self.config.DENSE_UNITS, activation='relu'),
            Dense(1)
        ])
        
        model.compile(
            optimizer='adam', 
            loss='mean_squared_error',
            metrics=['mae']
        )
        
        return model
    
    def prepare_data(self, prices: np.ndarray) -> Tuple[np.ndarray, np.ndarray, MinMaxScaler]:
        """Prepare data for LSTM training"""
        # Initialize scaler
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled_data = scaler.fit_transform(prices.reshape(-1, 1))
        
        # Create sequences
        X, y = [], []
        for i in range(self.config.TIME_STEP, len(scaled_data)):
            X.append(scaled_data[i-self.config.TIME_STEP:i, 0])
            y.append(scaled_data[i, 0])
        
        return np.array(X), np.array(y), scaler
    
    def train_single_stock(self, ticker: str, train_data: pd.Series) -> Optional[float]:
        """Train LSTM model for a single stock and predict return"""
        try:
            # Get training data
            prices = train_data.dropna().values
            
            # Check if we have enough data
            if len(prices) < self.config.TIME_STEP + 100:
                return None
            
            # Prepare data
            X_train, y_train, scaler = self.prepare_data(prices)
            X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))
            
            # Create and train model
            model = self.create_model((X_train.shape[1], 1))
            
            history = model.fit(
                X_train, y_train,
                epochs=self.config.EPOCHS,
                batch_size=self.config.BATCH_SIZE,
                verbose=0,
                validation_split=0.1
            )
            
            # Store model and scaler
            self.models[ticker] = model
            self.scalers[ticker] = scaler
            
            # Make prediction
            predicted_return = self.predict_return(ticker, prices, scaler, model)
            
            return predicted_return
            
        except Exception as e:
            print(f"⚠ Error training {ticker}: {e}")
            return None
    
    def predict_return(self, ticker: str, prices: np.ndarray, 
                      scaler: MinMaxScaler, model: Sequential) -> float:
        """Predict future return for a stock"""
        # Get last TIME_STEP days
        last_days = prices[-self.config.TIME_STEP:]
        last_days_scaled = scaler.transform(last_days.reshape(-1, 1))
        
        # Reshape for LSTM
        X_test = last_days_scaled.reshape((1, self.config.TIME_STEP, 1))
        
        # Predict next price
        predicted_price = model.predict(X_test, verbose=0)
        predicted_price = scaler.inverse_transform(predicted_price)
        
        # Calculate return
        current_price = prices[-1]
        predicted_return = (predicted_price[0][0] - current_price) / current_price
        
        return predicted_return
    
    def train_and_predict_all(self, train_data: pd.DataFrame, 
                            tickers: List[str]) -> Dict[str, float]:
        """Train LSTM models for all stocks and predict returns"""
        print("\n" + "="*60)
        print("LSTM TRAINING PHASE")
        print("="*60)
        
        predictions = {}
        total_stocks = len(tickers)
        successful = 0
        
        # Process in batches
        batch_size = self.config.BATCH_PROCESSING_SIZE
        
        for batch_start in range(0, total_stocks, batch_size):
            batch_end = min(batch_start + batch_size, total_stocks)
            batch_stocks = tickers[batch_start:batch_end]
            
            print(f"\nBatch {batch_start//batch_size + 1}/{(total_stocks-1)//batch_size + 1}: "
                  f"Stocks {batch_start + 1}-{batch_end} of {total_stocks}")
            
            for ticker in batch_stocks:
                if ticker in train_data.columns:
                    predicted_return = self.train_single_stock(ticker, train_data[ticker])
                    
                    if predicted_return is not None:
                        predictions[ticker] = predicted_return
                        successful += 1
            
            # Print progress
            print(f"Progress: {successful}/{batch_end} stocks trained successfully")
        
        print(f"\n✓ Successfully trained LSTM models for {len(predictions)}/{total_stocks} stocks")
        
        # Print top predictions
        self._print_top_predictions(predictions, n=10)
        
        return predictions
    
    def _print_top_predictions(self, predictions: Dict[str, float], n: int = 10):
        """Print top predicted stocks"""
        sorted_predictions = sorted(predictions.items(), key=lambda x: x[1], reverse=True)
        
        print(f"\nTop {n} LSTM Predictions:")
        print("-" * 40)
        for i, (ticker, pred_return) in enumerate(sorted_predictions[:n], 1):
            print(f"{i:2d}. {ticker:5s} : {pred_return:+7.2%}")
    
    def save_models(self, path: str = None):
        """Save trained models and scalers"""
        if path is None:
            path = self.config.MODELS_DIR
            
        os.makedirs(path, exist_ok=True)
        
        # Save models
        for ticker, model in self.models.items():
            model.save(f"{path}/{ticker}_model.h5")
        
        # Save scalers
        with open(f"{path}/scalers.pkl", 'wb') as f:
            pickle.dump(self.scalers, f)
            
        print(f"✓ Models saved to {path}")
    
    def load_models(self, path: str = None):
        """Load saved models and scalers"""
        if path is None:
            path = self.config.MODELS_DIR
            
        # Implementation for loading models
        pass
