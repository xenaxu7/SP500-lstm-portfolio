"""
Configuration settings for S&P 500 LSTM Portfolio Selection
"""

from datetime import datetime, timedelta

class Config:
    """Configuration class for all project settings"""
    
    def __init__(self):
        # Time Periods
        self.TESTING_END = datetime(2024, 12, 31)
        self.TESTING_START = datetime(2023, 7, 1)
        self.TRAINING_END = self.TESTING_START - timedelta(days=1)
        self.TRAINING_START = datetime(2013, 7, 1)
        
        # Model Parameters
        self.TIME_STEP = 60  # Days of historical data for LSTM
        self.EPOCHS = 3  # Number of training epochs (reduced for speed)
        self.BATCH_SIZE = 32  # Training batch size
        self.LSTM_UNITS_1 = 50  # Units in first LSTM layer
        self.LSTM_UNITS_2 = 50  # Units in second LSTM layer
        self.DENSE_UNITS = 25  # Units in dense layer
        
        # Portfolio Parameters
        self.NUM_STOCKS_TO_SELECT = 30  # Number of stocks in portfolio
        self.REBALANCE_FREQUENCY = 'quarterly'  # Not implemented yet
        self.RISK_FREE_RATE = 0.02  # Annual risk-free rate for Sharpe ratio
        
        # Data Parameters
        self.MIN_DATA_THRESHOLD = 0.5  # Minimum data availability threshold
        self.BATCH_PROCESSING_SIZE = 50  # Stocks to process in each batch
        
        # Thematic Portfolio (ChatGPT Selection)
        self.THEMATIC_STOCKS = [
            # Technology & AI
            'NVDA', 'MSFT', 'AVGO', 'GOOGL', 'AMZN', 'ADBE', 'ORCL', 'META',
            'CRM', 'NOW', 'INTC', 'AMD', 'QCOM', 'TXN', 'MU', 'PLTR',
            # Healthcare
            'UNH', 'MRK', 'LLY', 'JNJ', 'ABBV', 'PFE', 'TMO',
            # Financial
            'V', 'MA', 'JPM', 'USB', 'BRK-B',
            # Consumer
            'WMT', 'COST', 'PEP', 'PG', 'KO', 'MCD', 'HD', 'NKE',
            # Energy & Industrial
            'XOM', 'NEE', 'HON', 'UNP', 'WM',
            # Entertainment & Software
            'NFLX', 'DIS', 'INTU', 'FTNT'
        ]
        
        # Output Settings
        self.OUTPUT_DIR = 'results/'
        self.FIGURES_DIR = 'results/figures/'
        self.METRICS_DIR = 'results/metrics/'
        self.MODELS_DIR = 'models/'
        
        # Visualization Settings
        self.FIGURE_SIZE = (14, 7)
        self.DPI = 100
        self.STYLE = 'seaborn-v0_8-darkgrid'
        
    def get_date_range_string(self):
        """Get formatted date range string"""
        return (f"Training: {self.TRAINING_START.date()} to {self.TRAINING_END.date()}\n"
                f"Testing: {self.TESTING_START.date()} to {self.TESTING_END.date()}")
